-- 夺宝师徒练

x806020_g_ScriptId = 806020

x806020_g_Validate_Time_Mail	= {startTime = 20080703, endTime = 20080814}
x806020_g_Validate_Time_Change	= {startTime = 20080703, endTime = 20080821}

x806020_g_Need_Item_List = { 20310109, 20310108, 20310107, 20310106 }

x806020_g_Prize_List = 	{
						 	{id=30309713, count=1, rand=400 , 	bind = 0},
						 	{id=30309716, count=1, rand=160  , 	bind = 0},
						 	{id=30309717, count=1, rand=80  , 	bind = 0},
						 	{id=30900006, count=1, rand=920 , 	bind = 1},
						 	{id=30008034, count=1, rand=200 , 	bind = 1},
						 	{id=30900045, count=1, rand=100 , 	bind = 1},
						 	{id=30008021, count=1, rand=200 , 	bind = 1},
						 	{id=30008022, count=1, rand=200 , 	bind = 1},
						 	{id=30008023, count=1, rand=200 , 	bind = 1},
						 	{id=30008024, count=1, rand=200 , 	bind = 1},
						 	{id=30008025, count=1, rand=200 , 	bind = 1},
						 	{id=30505034, count=1, rand=125 , 	bind = 0},
						 	{id=30505035, count=1, rand=125 , 	bind = 0},
						 	{id=30505036, count=1, rand=125 , 	bind = 0},
						 	{id=30505037, count=1, rand=125 , 	bind = 0},
						 	{id=30505038, count=1, rand=125 , 	bind = 0},
						 	{id=30505039, count=1, rand=125 , 	bind = 0},
						 	{id=30505040, count=1, rand=125 , 	bind = 0},
						 	{id=30505041, count=1, rand=125 , 	bind = 0},
						 	{id=30008016, count=1, rand=500 , 	bind = 1},
						 	{id=30008002, count=1, rand=500 , 	bind = 1},
						 	{id=30008003, count=1, rand=500 , 	bind = 1},
						 	{id=30501017, count=1, rand=500 , 	bind = 1},
						 	{id=30501023, count=1, rand=500 , 	bind = 1},
						 	{id=30503018, count=1, rand=1100, 	bind = 1},   
						 	{id=30503019, count=1, rand=200 , 	bind = 1},
						 	{id=30900009, count=1, rand=500 , 	bind = 1},
						 	{id=30900011, count=1, rand=500 , 	bind = 1},
						 	{id=30900010, count=1, rand=140 , 	bind = 1},
						 	{id=30008009, count=1, rand=200 , 	bind = 1},
						 	{id=30900015, count=1, rand=800 , 	bind = 1},
						 	{id=30900016, count=1, rand=200 , 	bind = 1},
						}       
						        
x806020_g_Prize_List_long = 	{--zchw
						 	{id=30309713, count=1, rand=500 , 	bind = 0}, --唐装鼠
						 	{id=30309716, count=1, rand=200  , 	bind = 0}, --唐装鼠
						 	{id=30309717, count=1, rand=100  , 	bind = 0}, --唐装鼠
						 	{id=30900006, count=1, rand=860 , 	bind = 1},
						 	{id=30008034, count=1, rand=200 , 	bind = 1},
						 	{id=30900045, count=1, rand=100 , 	bind = 1},
						 	{id=30008021, count=1, rand=200 , 	bind = 1},
						 	{id=30008022, count=1, rand=200 , 	bind = 1},
						 	{id=30008023, count=1, rand=200 , 	bind = 1},
						 	{id=30008024, count=1, rand=200 , 	bind = 1},
						 	{id=30008025, count=1, rand=200 , 	bind = 1},
						 	{id=30505034, count=1, rand=125 , 	bind = 0},
						 	{id=30505035, count=1, rand=125 , 	bind = 0},
						 	{id=30505036, count=1, rand=125 , 	bind = 0},
						 	{id=30505037, count=1, rand=125 , 	bind = 0},
						 	{id=30505038, count=1, rand=125 , 	bind = 0},
						 	{id=30505039, count=1, rand=125 , 	bind = 0},
						 	{id=30505040, count=1, rand=125 , 	bind = 0},
						 	{id=30505041, count=1, rand=125 , 	bind = 0},
						 	{id=30008016, count=1, rand=500 , 	bind = 1},
						 	{id=30008002, count=1, rand=500 , 	bind = 1},
						 	{id=30008003, count=1, rand=500 , 	bind = 1},
						 	{id=30501017, count=1, rand=500 , 	bind = 1},
						 	{id=30501023, count=1, rand=500 , 	bind = 1},
						 	{id=30503018, count=1, rand=1000, 	bind = 1},   
						 	{id=30503019, count=1, rand=200 , 	bind = 1},
						 	{id=30900009, count=1, rand=500 , 	bind = 1},
						 	{id=30900011, count=1, rand=500 , 	bind = 1},
						 	{id=30900010, count=1, rand=140 , 	bind = 1},
						 	{id=30008009, count=1, rand=200 , 	bind = 1},
						 	{id=30900015, count=1, rand=800 , 	bind = 1},
						 	{id=30900016, count=1, rand=200 , 	bind = 1},

						}       
                                
x806020_g_Prize_List_30_master =	{
										--type 0:物品    1:经验
										{type=0, value=20310106 },
										{type=0, value=20310107 },
										{type=1, value=300000 },	
									}
									
x806020_g_Prize_List_30_prentice =	{
										--type 0:物品    1:经验
										{type=0, value=30008027 },	
									}
									
x806020_g_Prize_List_45_master =	{
										--type 0:物品    1:经验
										{type=0, value=20310106 },
										{type=0, value=20310107 },
										{type=1, value=300000 },	
									}
									
x806020_g_Prize_List_45_prentice =	{
										--type 0:物品    1:经验
										{type=0, value=31000006 },	
									}									
							
							
x806020_g_Impact_List = {8058, 8059, 8060, 8061}



									

function x806020_IsValidateTime_Mail(  )
	local curDayTime = GetTime2Day()
	if	( curDayTime >= x806020_g_Validate_Time_Mail.startTime ) and ( curDayTime <= x806020_g_Validate_Time_Mail.endTime ) then
		return 1
	elseif curDayTime > x806020_g_Validate_Time_Mail.endTime then
		return 2
	end
	return 0
end

function x806020_IsValidateTime_Change(  )
	local curDayTime = GetTime2Day()
	if	( curDayTime >= x806020_g_Validate_Time_Change.startTime ) and ( curDayTime <= x806020_g_Validate_Time_Change.endTime ) then
		return 1
	elseif curDayTime >= x806020_g_Validate_Time_Change.startTime then
		return 2
	end
	return 0
end

function x806020_OnPlayerLogin( sceneId, selfId )
	if ( x806020_IsValidateTime_Mail() == 1 and GetLevel(sceneId, selfId) >= 10 ) then
		local flag = GetMissionFlag(sceneId, selfId, MF_ShiTuHelp_Mail)
		if (flag == 0) then
			LuaFnSendSystemMail( sceneId, GetName( sceneId, selfId ), "#{STZDY_20080513_04}" )
			SetMissionFlag(sceneId, selfId, MF_ShiTuHelp_Mail, 1)
		end
	end
end

--**********************************
--玩家升级时回调此函数
--**********************************
function x806020_OnPlayerLevelUp( sceneId, selfId )

	if x806020_IsValidateTime_Mail() == 0 then
		return
	end
	
	if LuaFnHaveMaster(sceneId, selfId ) ~= 1 and GetMissionFlag( sceneId, selfId, MF_ShiTu_ChuShi_Flag ) ~= 1 then
		return
	end

	local CurLevel = GetLevel( sceneId, selfId )
	local masterGuid = LuaFnGetMasterGUID( sceneId, selfId )
	
	if CurLevel == 30 then
		local prenticeMsg	= format("#{STZDY_20080513_05}%d#{STZDY_20080513_06}", CurLevel)
		local masterMsg		= format("#{STZDY_20080513_07}%s#{STZDY_20080513_08}%d#{STZDY_20080513_09}", GetName( sceneId, selfId ), CurLevel)
		LuaFnSendSystemMail( sceneId, GetName( sceneId, selfId ), prenticeMsg )
		LuaFnSendMailToGUID(sceneId, masterGuid, masterMsg)
		return
	end
	
	if CurLevel == 45 then
		local prenticeMsg	= format("#{STZDY_20080513_05}%d#{STZDY_20080513_06}", CurLevel)
		local masterMsg		= format("#{STZDY_20080513_07}%s#{STZDY_20080513_08}%d#{STZDY_20080513_09}", GetName( sceneId, selfId ), CurLevel)
		LuaFnSendSystemMail( sceneId, GetName( sceneId, selfId ), prenticeMsg )
		LuaFnSendMailToGUID(sceneId, masterGuid, masterMsg)
		return
	end

end


--**********************************
--任务入口函数
--**********************************
function x806020_OnDefaultEvent( sceneId, selfId, targetId )

	if x806020_IsValidateTime_Change() ==0 then
		x806020_NotifyMsg( sceneId, selfId, targetId,  "暂无兑奖活动" )
	end
	
	if(GetNumText() == 1) then
		BeginEvent(sceneId)
			AddText(sceneId, "#{STZDY_20080513_19}")
			AddNumText( sceneId, x806020_g_ScriptId, "参加抽奖", 6, 3 )
			AddNumText( sceneId, x806020_g_ScriptId, "领取师徒升级乐奖品", 6, 4 )
			AddNumText( sceneId, x806020_g_ScriptId, "兑换夺宝师徒练BUFF", 6, 5 )
		EndEvent( sceneId )
		DispatchEventList( sceneId, selfId, targetId )
	elseif (GetNumText() == 2) then
		BeginEvent(sceneId)
			AddText(sceneId, "#{STZDY_20080513_45}")
		EndEvent( sceneId )
		DispatchEventList( sceneId, selfId, targetId )
	elseif (GetNumText() == 3) then
		--等级10
		local level = GetLevel( sceneId, selfId )
		if level < 10 then
			BeginEvent(sceneId)
				AddText(sceneId, "#{STZDY_20080513_21}")
			EndEvent( sceneId )
			DispatchEventList( sceneId, selfId, targetId )
			return
		end
		
		--每天1次限制
		local dayCount = GetMissionData( sceneId, selfId, MD_SHITUZONGDONGYUAN_PRIZE_COUNT )
		local curDayTime = GetTime2Day()
		if curDayTime == floor( dayCount / 100) then
			if dayCount - curDayTime * 100 >= 1 then
				BeginEvent(sceneId)
					AddText(sceneId, "#{STZDY_20080513_22}")
				EndEvent( sceneId )
				DispatchEventList( sceneId, selfId, targetId )
				return
			end
		end 
		
		
		--检查需求物品
		local i
		for i=1, getn(x806020_g_Need_Item_List) do
			if LuaFnGetAvailableItemCount(sceneId, selfId, x806020_g_Need_Item_List[i]) < 1 then
				BeginEvent(sceneId)
					AddText(sceneId, "#{STZDY_20080513_27}")
				EndEvent( sceneId )
				DispatchEventList( sceneId, selfId, targetId )
				return
			end
		end
		
		
		--抽奖
		local prizeList
		if x806020_IsValidateTime_Change() == 1 then
			prizeList = x806020_g_Prize_List
		elseif x806020_IsValidateTime_Change() == 2 then
			prizeList = x806020_g_Prize_List_long
		end
		
		if prizeList == nil or getn(prizeList) < 1 then
			return
		end
		
		local randMax = 0
		for i=1, getn(prizeList) do
			randMax = randMax + prizeList[i].rand
		end
		
		local randIndex = random(randMax)
		
		if randMax < 1 then
			return
		end
		
		for i=1, getn(prizeList) do
			if randIndex <= prizeList[i].rand then
				--道具栏已满
				if LuaFnGetPropertyBagSpace( sceneId, selfId ) < prizeList[i].count then
					x806020_NotifyTips(sceneId, selfId, "#{STZDY_20080513_24}")
					return
				end
		
				--开始添加奖励
				LuaFnBeginAddItem( sceneId )
				LuaFnAddItem( sceneId, prizeList[i].id, prizeList[i].count)
				local ret = LuaFnEndAddItem( sceneId, selfId )
				if 1 == ret then
					--扣除物品
					for i=1, getn(x806020_g_Need_Item_List) do
						if LuaFnDelAvailableItem(sceneId, selfId, x806020_g_Need_Item_List[i], 1) ~= 1 then
							BeginEvent(sceneId)
								AddText(sceneId, "#{STZDY_20080513_27}")
							EndEvent( sceneId )
							DispatchEventList( sceneId, selfId, targetId )
							return
						end
					end
					
					local dayCount = GetMissionData( sceneId, selfId, MD_SHITUZONGDONGYUAN_PRIZE_COUNT )
					local curDayTime = GetTime2Day()
					if curDayTime == floor( dayCount / 100) then
						SetMissionData( sceneId, selfId, MD_SHITUZONGDONGYUAN_PRIZE_COUNT, dayCount + 1 )
					else
						SetMissionData( sceneId, selfId, MD_SHITUZONGDONGYUAN_PRIZE_COUNT, curDayTime * 100 + 1 )
					end 
					
					local bagPos = -1
					for count=1, prizeList[i].count do
						bagPos = TryRecieveItem( sceneId, selfId, prizeList[i].id, QUALITY_MUST_BE_CHANGE )
						if prizeList[i].bind == 1 then
							LuaFnItemBind( sceneId, selfId, bagPos )
						end
					end
					
					AuditShiTuZongDongYuan( sceneId, selfId, " GetAward_Random: id="..prizeList[i].id)
	
					if	prizeList[i].id == 30309713 
						or prizeList[i].id == 30309716 
						or prizeList[i].id == 30309717
						or prizeList[i].id == 30008034
						or prizeList[i].id == 30900045
					then
						local scrollMsg = format("@*;SrvMsg;SCA:#{STZDY_20080513_10}#{_INFOUSR%s}#{STZDY_20080513_11}#{_INFOMSG%s}#{STZDY_20080513_12}", GetName( sceneId, selfId ), GetBagItemTransfer(sceneId, selfId, bagPos  ) )
						BroadMsgByChatPipe(sceneId, selfId, scrollMsg, 4);
					else
						SetMissionFlag( sceneId, selfId, MF_ActiveWenZhouCard, 1 )
						local scrollMsg = format("#{STZDY_20080513_13}#{_INFOUSR%s}#{STZDY_20080513_14}#{_INFOMSG%s}#{STZDY_20080513_15}", GetName( sceneId, selfId ), GetBagItemTransfer(sceneId, selfId, bagPos  ) )
						BroadMsgByChatPipe(sceneId, selfId, scrollMsg, 4);
					end
					local msg = format("#{STZDY_20080513_25}#{_INFOMSG%s}#{STZDY_20080513_26}", GetBagItemTransfer(sceneId, selfId, bagPos ) )
					BeginEvent(sceneId)
						AddText(sceneId, msg)
					EndEvent( sceneId )
					DispatchEventList( sceneId, selfId, targetId )
				end
				return
			else
				randIndex = randIndex - prizeList[i].rand
			end
		end
		
	elseif (GetNumText() == 4) then
		BeginEvent(sceneId)
			AddText(sceneId, "#{STZDY_20080513_28}")
			AddNumText( sceneId, x806020_g_ScriptId, "领取30级奖励", 6, 6 )
			AddNumText( sceneId, x806020_g_ScriptId, "领取45级奖励", 6, 7 )
			AddNumText( sceneId, x806020_g_ScriptId, "再见", 6, 8 )
		EndEvent( sceneId )
		DispatchEventList( sceneId, selfId, targetId )
	elseif (GetNumText() == 5) then
		BeginEvent(sceneId)
			AddText(sceneId, "#{STZDY_20080513_43}")
			AddNumText( sceneId, x806020_g_ScriptId, "进行兑换", 6, 9 )
			AddNumText( sceneId, x806020_g_ScriptId, "还没准备好", 6, 8 )
		EndEvent( sceneId )
		DispatchEventList( sceneId, selfId, targetId )
	elseif (GetNumText() == 6) or (GetNumText() == 7) then
		local sNotifyMsg = "#{STZDY_20080513_31}"
		local sNotifyTips = "#{STZDY_20080513_32}"
		
		if GetMissionFlag( sceneId, selfId, MF_ShiTu_ChuShi_Flag ) == 1 then --表示已经出师
			if GetNumText() == 6 then
				sNotifyMsg = "#{STZDY_20080513_29}"
				sNotifyTips = "#{STZDY_20080513_30}"
			else
				sNotifyMsg = "#{STZDY_20080513_41}"
				sNotifyTips = "#{STZDY_20080513_42}"
			end
		end
		
		if LuaFnHasTeam( sceneId, selfId ) == 0 then        			
	        x806020_NotifyMsg( sceneId, selfId, targetId,  sNotifyMsg )
	        x806020_NotifyTips( sceneId, selfId, sNotifyTips )				
	        return
	    end
	    
	    -- 组队中只有两个人
	    if LuaFnGetTeamSize( sceneId, selfId ) ~= 2 then
			x806020_NotifyMsg( sceneId, selfId, targetId,  sNotifyMsg )
	        x806020_NotifyTips( sceneId, selfId, sNotifyTips )								
	        return
		end 
		
		-- 组队中的两个人必须都在附近
	    local	numMem	= GetNearTeamCount( sceneId, selfId )
	    if numMem ~= LuaFnGetTeamSize( sceneId, selfId ) then                
			x806020_NotifyMsg( sceneId, selfId, targetId,  sNotifyMsg )
	        x806020_NotifyTips( sceneId, selfId, sNotifyTips )							
	        return
	    end
	    
	    local otherId = LuaFnGetTeamSceneMember( sceneId, selfId, 0 )     
    
    	-- 领取者是否为师徒
	    if LuaFnIsMasterEver(sceneId, selfId, otherId) ~= 1 and LuaFnIsMasterEver(sceneId, otherId, selfId) ~= 1 then
			x806020_NotifyMsg( sceneId, selfId, targetId,  sNotifyMsg )
	        x806020_NotifyTips( sceneId, selfId, sNotifyTips )								
	        return			
	    end
	    
	    if LuaFnIsMasterEver(sceneId, otherId, selfId) == 1 then
	    	--我是师傅
	    	if GetMissionFlag( sceneId, otherId, MF_ShiTu_ChuShi_Flag ) == 1 then
	    		sNotifyMsg = "#{STZDY_20080513_41}"
				sNotifyTips = "#{STZDY_20080513_42}"
			else
				sNotifyMsg = "#{STZDY_20080513_31}"
				sNotifyTips = "#{STZDY_20080513_32}"
	    	end
	    elseif LuaFnIsMasterEver(sceneId, selfId, otherId ) == 1 then
	    	--我是徒弟
	    	if GetMissionFlag( sceneId, selfId, MF_ShiTu_ChuShi_Flag ) == 1 then
	    		sNotifyMsg = "#{STZDY_20080513_41}"
				sNotifyTips = "#{STZDY_20080513_42}"
			else
				sNotifyMsg = "#{STZDY_20080513_31}"
				sNotifyTips = "#{STZDY_20080513_32}"
	    	end
	    end
	    	
	    
	    if LuaFnGetFriendPoint(sceneId, selfId, otherId)<500 or LuaFnGetFriendPoint(sceneId, otherId, selfId)<500 then
	    	x806020_NotifyMsg( sceneId, selfId, targetId,  "#{STZDY_20080513_33}" )
	        x806020_NotifyTips( sceneId, selfId, "#{STZDY_20080513_34}" )			
	        return   
	    end

		local levelReq
		local strTip = ""
		local strMsg = ""
		local prizeList_master
		local prizeList_prentice
		local MF_master
		local MF_prentice
		local strAwardLevel;
		if GetNumText() == 6 then
			levelReq = 30
			strTip = "#{STZDY_20080513_39}"
			strMsg = "#{STZDY_20080513_40}"
			prizeList_master = x806020_g_Prize_List_30_master
			prizeList_prentice = x806020_g_Prize_List_30_prentice
			MF_master = MF_ShiTuHelp_30_master
			MF_prentice = MF_ShiTuHelp_30_prentice
			strAwardLevel = 30
		elseif GetNumText() == 7 then
			levelReq = 45
			strTip = "徒弟升至45级才能领取奖励哦！"
			strMsg = "徒弟必须升至45级才能领取！"
			prizeList_master = x806020_g_Prize_List_45_master
			prizeList_prentice = x806020_g_Prize_List_45_prentice
			MF_master = MF_ShiTuHelp_45_master
			MF_prentice = MF_ShiTuHelp_45_prentice
			strAwardLevel = 45
		end
	    
	    if LuaFnIsMasterEver(sceneId, otherId, selfId) == 1 then
	    	--师傅
	    	if GetLevel(sceneId, otherId) < levelReq then
	    		x806020_NotifyMsg( sceneId, selfId, targetId,  strTip )
		        x806020_NotifyTips( sceneId, selfId, strMsg )			
		        return    
	    	end
	    	
	    	local flag = GetMissionFlag(sceneId, otherId, MF_master)
	    	if flag == 1 then
				x806020_NotifyMsg( sceneId, selfId, targetId,  "#{STZDY_20080513_35}" )
	        	x806020_NotifyTips( sceneId, selfId, "#{STZDY_20080513_35}" )			
	        	return    
	    	end
	    	
	    	
	    	--奖励
	    	if ( x806020_GivePrize( sceneId, selfId, prizeList_master) == 0 ) then
	    		x806020_NotifyMsg( sceneId, selfId, targetId,  "#{STZDY_20080513_36}" )
	        	x806020_NotifyTips( sceneId, selfId, "#{STZDY_20080513_37}" )			
	        	return   
	    	end
	    	
	    	AuditShiTuZongDongYuan( sceneId, selfId, " GetAward_Master_"..strAwardLevel)
	    	
	    	SetMissionFlag(sceneId, otherId, MF_master, 1)
	    	
			x806020_NotifyMsg( sceneId, selfId, targetId,  "#{STZDY_20080513_38}")
	    	
	    elseif LuaFnIsMasterEver(sceneId, selfId, otherId ) == 1 then
	    	--徒弟
	    	if GetLevel(sceneId, selfId) < levelReq then
	    		x806020_NotifyMsg( sceneId, selfId, targetId,  strTip )
		        x806020_NotifyTips( sceneId, selfId, strMsg )			
		        return    
	    	end
	    	
	    	local flag = GetMissionFlag(sceneId, selfId, MF_prentice)
	    	if flag == 1 then
				x806020_NotifyMsg( sceneId, selfId, targetId,  "#{STZDY_20080513_35}" )
	        	x806020_NotifyTips( sceneId, selfId, "#{STZDY_20080513_35}" )			
	        	return    
	    	end
	    	
	    	--奖励
	    	if( x806020_GivePrize( sceneId, selfId, prizeList_prentice) == 0 ) then
	    		x806020_NotifyMsg( sceneId, selfId, targetId,  "#{STL_0623_01}" )
	        	x806020_NotifyTips( sceneId, selfId, "#{STZDY_20080513_37}" )			
	        	return   
	    	end
	    	
	    	AuditShiTuZongDongYuan( sceneId, selfId, " GetAward_Prentice_"..strAwardLevel)
	    	
	    	SetMissionFlag(sceneId, selfId, MF_prentice, 1)
	    	
			x806020_NotifyMsg( sceneId, selfId, targetId,  "#{STZDY_20080513_38}")
	    	
	    end
	
	elseif (GetNumText() == 8) then
		BeginUICommand(sceneId)
		EndUICommand(sceneId)
		DispatchUICommand(sceneId,selfId, 1000)
		return
	elseif (GetNumText() == 9) then
		
		--检查需求物品
		local i
		for i=1, getn(x806020_g_Need_Item_List) do
			if LuaFnGetAvailableItemCount(sceneId, selfId, x806020_g_Need_Item_List[i]) > 0 then				
				--扣除物品
				if LuaFnDelAvailableItem(sceneId, selfId, x806020_g_Need_Item_List[i], 1) == 1 then
					--加buff
					local buffId = x806020_g_Impact_List[ random( getn(x806020_g_Impact_List) ) ]
					LuaFnSendSpecificImpactToUnit(sceneId, selfId, selfId, selfId, buffId, 0);
					
					AuditShiTuZongDongYuan( sceneId, selfId, " GetAward_Buff")
					
					x806020_NotifyMsg( sceneId, selfId, targetId,  "兑换成功。" )
					
					return
				end
			end
		end
		
		x806020_NotifyMsg( sceneId, selfId, targetId,  "#{STZDY_20080513_44}" )
		
		return
		
	end
end

--**********************************
--列举事件
--**********************************
function x806020_OnEnumerate( sceneId, selfId, targetId )

	if x806020_IsValidateTime_Change() == 0 then
		return
	end
	
	AddNumText( sceneId, x806020_g_ScriptId, "夺宝师徒练活动", 6, 1 )
	AddNumText( sceneId, x806020_g_ScriptId, "夺宝师徒练活动帮助", 11, 2 )

end


function x806020_NotifyTips( sceneId, selfId, Tip )
	BeginEvent( sceneId )
		AddText( sceneId, Tip )
	EndEvent( sceneId )
	DispatchMissionTips( sceneId, selfId )
end

function x806020_NotifyMsg( sceneId, selfId,  targetId, Msg )
	BeginEvent( sceneId )
		AddText( sceneId, Msg )
	EndEvent( sceneId )
	DispatchEventList( sceneId, selfId, targetId )
end


function x806020_GivePrize( sceneId, selfId, pList)
	local i
	
	--添加物品
	LuaFnBeginAddItem( sceneId )
	for i=1, getn(pList) do
		if pList[i].type == 0 then
			LuaFnAddItem( sceneId, pList[i].value, 1)
		end
	end
	local ret = LuaFnEndAddItem( sceneId, selfId )
	if 1 == ret then
		AddItemListToHuman(sceneId,selfId)
	else		
		return 0
	end
	
	--添加经验
	for i=1, getn(pList) do
		if pList[i].type == 1 then
			AddExp( sceneId, selfId, pList[i].value )
		end
	end
	
	return 1
end
