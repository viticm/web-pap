-- 解除结拜

--脚本号
x806002_g_scriptId = 806002

--**********************************
--列举事件
--**********************************
function x806002_OnEnumerate( sceneId, selfId, targetId )
	
end
