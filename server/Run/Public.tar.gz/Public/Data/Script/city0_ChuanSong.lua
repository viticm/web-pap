--玩家进入一个 area 时触发

 function x805021_OnEnterArea( sceneId, selfId )
		CityMoveToPort(sceneId, selfId)
 end



--玩家在一个 area 呆了一段时间没走则定时触发

function x805021_OnTimer( sceneId, selfId )
	
end



--玩家离开一个 area 时触发

 function x805021_OnLeaveArea( sceneId, selfId )

end


